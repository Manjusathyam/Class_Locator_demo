package com.example.classdemo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class classdemo {
    public static void main(String[] args) {
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();

        driver.get("https://demo.guru99.com/test/login.html");
        driver.manage().window().maximize();

        WebElement email = driver.findElement(By.className("account_input"));
        email.sendKeys("admin@gmail.com");
        
        WebElement password = driver.findElement(By.className("validate"));
        password.sendKeys("admin123");

        WebElement signin = driver.findElement(By.className("btn-default"));
        signin.click();

        driver.quit();

    }
}
